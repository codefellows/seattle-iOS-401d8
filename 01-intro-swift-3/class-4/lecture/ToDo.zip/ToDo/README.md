# ToDo
Simple project demonstrating the awesomeness of Swift protocols and protocol extensions.

You can find the actual tutorial on my blog [here](http://www.michaelbabiy.com/reusability-with-swift-protocols/).

Please don't hesitate to contact me if you have any questions or suggestions.

twitter: [@michaelbabiy](https://twitter.com/michaelbabiy)

in: [in/michaelbabiy](https://www.linkedin.com/in/michaelbabiy)
